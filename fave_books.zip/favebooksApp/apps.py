from django.apps import AppConfig


class FavebooksappConfig(AppConfig):
    name = 'favebooksApp'
